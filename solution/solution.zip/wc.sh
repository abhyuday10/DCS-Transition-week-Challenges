#!/bin/sh

# This file should run your code to solve the word count problem when called as /bin/sh wc.sh <file_to_sort>
# In this example, it simply executes the provided java program Wc.

./wc $1